# Que: Given an integer N, return the first N rows of Pascal’s triangle.

def generate(numRows: int) :
        r = [[1]*(i+1) for i in range(numRows)]
        for i in range(2,numRows):
            for j in range(1,i):
                r[i][j] = r[i-1][j-1] + r[i-1][j]
        return r
if __name__ == '__main__':
    print(generate(5))