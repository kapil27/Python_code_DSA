# Problem Statement: You are given an array of prices where prices[i] is the price of a given stock on an ith day.

# You want to maximize your profit by choosing a single day to buy one stock and choosing a different day in the future to sell that 
# stock. 
# Return the maximum profit you can achieve from this transaction. If you cannot achieve any profit, return 0.

#  naive : 

# def max_profit(arr):
#     max_pro = 0
#     for i in range(len(arr)):
#         for j in range(i,len(arr)):
#             if arr[j]-arr[i]>max_pro:
#                 max_pro = arr[j]-arr[i]
#     return max_pro
import sys

def max_profit(arr):
    max_pro = 0
    min_price = sys.maxsize
    for i in range(len(arr)):
        if min_price>arr[i]:
            min_price = arr[i]
        if max_pro<arr[i]-min_price:
            max_pro = arr[i]-min_price
    return max_pro
if __name__ == "__main__":
    print(max_profit([7,1,5,3,6,4,99]))