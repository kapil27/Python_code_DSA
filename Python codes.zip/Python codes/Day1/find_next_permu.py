# next_permutation : find next lexicographically greater permutation

# Given an array Arr[] of integers, 
# rearrange the numbers of the given array into the lexicographically next greater permutation of numbers.

#input : 123
# OUTPUT :  132


def next_permutation(array):
    n = len(array)
    # print(array)
    i = 0
    l=0
    for i in range(n-2,-1,-1):
        # print("pass")
        if array[i]<array[i+1]:
            break
    if i<0:
        return array[::-1]
    else:
        for l in range(n-1,i,-1):
            if array[l]>array[i]:
                break
    # print(i,l)
    array[i],array[l] = array[l],array[i]
    # print(array[i+1::-1])
    array = array[i+1::-1][::-1]
    print(array)

if __name__ == "__main__":
    next_permutation([1,2,3,4,5,6])

