# Problem Statement: Given an integer array arr, find the contiguous subarray (containing at least one number) which
# has the largest sum and return its sum and print the subarray

def kadane(arr,sub):
    max_end_here = 0
    max_so_far = arr[0] 
    for i in range(len(arr)):
        # sub.append(i)
        max_end_here+=arr[i]
        if max_end_here>max_so_far:
            sub = []
            max_so_far=max_end_here
            sub.append(s)
            sub.append(i)

        if max_end_here<0:
            max_end_here=0
            s=i+1
    return max_so_far,sub

if __name__ == "__main__":
    print(kadane([-2,1,-3,4,-1,2,1,-5,4],[]))