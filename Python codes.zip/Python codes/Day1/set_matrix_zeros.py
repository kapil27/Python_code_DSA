# QUE: Given a matrix if an element in the matrix is 0 then you will have to set 
# its entire column and row to 0 and then return the matrix.

# Instead of taking two separate dummy array,take first row and column of the matrix as the array for checking whether t
# he particular column or row has the value 0 or not.Since matrix[0][0] are overlapping.Therefore take separate variable col0(say) 
# to check if the 0th column has 0 or not and use matrix[0][0] to check if the 0th row has 0 or not.Now traverse from last element 
# to the first element and check if matrix[i][0]==0 || matrix[0][j]==0 and if true set matrix[i][j]=0,else continue.


# ------------- WRONG --------------------------#
from os import *
from sys import *
from collections import *
from math import *

from typing import List


    
def setZeros(matrix: List[List[int]]) -> None:
    n = len(matrix)
    m = len(matrix[0])
    FirstRow = False
    FirstColumn = False
    for i in range(m):
        if matrix[i][0] == 0:
            FirstRow = True
    for j in range(n):
        if matrix[0][j] == 0:
            FirstColumn = True
    for i in range(m):
        for j in range(n):
            if matrix[i][j]==0:
                matrix[i][0] = 0
                matrix[0][j] = 0
    for i in range(m):
        for j in range(n):
            if matrix[i][0]==0 or matrix[0][j]==0:
                matrix[i][j]=0
    if FirstRow==True:
        for i in range(n):
            matrix[i][0]=0
    if FirstColumn==True:
        for i in range(m):
            matrix[0][i]=0
    return matrix

print(setZeros([[1,2,0],[0,1,1],[3,4,5]]))