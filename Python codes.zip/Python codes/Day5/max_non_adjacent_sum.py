from sys import stdin

def maximumNonAdjacentSum(nums):    
#    dp = [-1]*len(nums)
#    non_pick = 0
#    dp[0] = nums[0]
#    for i in range(1,n):
#        pick = nums[i]
#        if i>1:
#            pick += dp[i-2]
# #        non_pick = 0
#        non_pick = dp[i-1]
#        dp[i] = max(pick,non_pick)

#    return dp[n-1]
    def solve(ind,nums):
        if ind==0:
            return nums[ind]
        if ind<0:
            return 0
        pick = nums[ind]+solve(ind-2,nums)
        non_pick = solve(ind-1,nums)
        return max(pick,non_pick)


#     def solve(ind,nums):
#         if ind==0:
#             return nums[ind]
#         if ind<0:
#             return 0
#         pick = nums[ind]+solve(ind-2,nums)
#         non_pick = solve(ind-1,nums)
#         return max(pick,non_pick)
#     ind = len(nums)-1
#     return solve(ind,nums)
# # Main.
t = int(stdin.readline().rstrip())

while t > 0:
    
    n = int(stdin.readline().rstrip())
    arr = list(map(int, stdin.readline().rstrip().split(" ")))
    print(maximumNonAdjacentSum(arr))
    
    t -= 1