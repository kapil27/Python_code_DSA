# Merge Overlapping Sub-intervals
# Problem Statement: Given an array of intervals, 
# merge all the overlapping intervals and return an array of non-overlapping intervals.

# intervals=[[1,3],[2,6],[8,10],[15,18]]

# output : [[1,6],[8,10],[15,18]]
def merge(intervals):
        intervals = sorted(intervals, key = lambda x:x[0])  # understand how lambda works
        a = [intervals[0]]
        # return(intervals)
        for i in range(1,len(intervals)):
            if intervals[i][0]<=a[-1][1] :
                if intervals[i][1]>=a[-1][-1]:
                    a[-1][1] = intervals[i][1]
            else:
                a.append(intervals[i])
        return a                

if __name__ == "__main__":
    mat= [[1,3],[2,6],[8,10],[15,18]]

    print(merge(mat))