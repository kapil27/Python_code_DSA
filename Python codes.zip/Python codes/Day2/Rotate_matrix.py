# Problem Statement: Given a matrix, your task is to rotate the matrix 90 degrees clockwise.

# Solution 1:Brute force

# Approach: Take another dummy matrix of n*n, 
# and then take the first row of the matrix and put it in the last column of the dummy matrix, take the second row of the matrix, 
# # and put it in the second last column of the matrix and so.


# for (int i = 0; i < n; i++) {
#     for (int j = 0; j < n; j++) {
#       rotated[j][n - i - 1] = matrix[i][j];
#     }
#   }

def rotate(arr):
    
    n = len(arr)

    for i in range(n):
        for j in range(0,i):
            arr[i][j],arr[j][i] = arr[j][i],arr[i][j]
    for i in range(n):
        arr[i] = arr[i][::-1]
    return arr
if __name__ =="__main__":
    mat = [[1,2,3],[4,5,6],[7,8,9]]
    print(rotate(mat))