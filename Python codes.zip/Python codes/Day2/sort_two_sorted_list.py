# Merge two Sorted Arrays Without Extra Space
# Problem statement: Given two sorted arrays arr1[] and arr2[] of sizes n and m 
# in non-decreasing order. Merge them in sorted order. Modify arr1 so that it contains the first N elements 
# and modify arr2 so that it contains the last M elements.


# Solution1: Brute Force-

# Intuition: We can use a new array of size n+m and put all elements of arr1 and arr2 in it,
#  and sort it. After sorting it, but all the elements in arr1 and arr2.


# Without using space-

# Intuition: We can think of Iterating in arr1 and whenever we encounter an element that is greater than the first element of arr2,
#  just swap it. Now rearrange the arr2 in a sorted manner,
#  after completion of the loop we will get elements of both the arrays in non-decreasing order.


import math

def merge_sorted(arr1,arr2):
    gap = math.ceil((len(arr1)+len(arr2))/2)
    n = len(arr1)
    # m = len(arr2)
    while(gap>0):
        i = 0
        j=gap
        while(j<(len(arr1)+len(arr2))):
            if j<n and arr1[i]>arr1[j]:
                arr1[i],arr1[j]=arr1[j],arr1[i]
            elif j>=n and i<n and arr1[i]>arr2[j-n]:
                arr1[i],arr2[j-n] = arr2[j-n],arr1[i]
            elif j>=n and i>=n and arr2[i-n]>arr2[j-n]:
                arr2[i-n],arr2[j-n] = arr2[j-n],arr2[i-n]

            i+=1
            j+=1
        if gap==1:
            gap=0
        else:
            gap = math.ceil(gap/2)
    print(arr1+arr2)

if __name__ == "_main__":
    arr1 = [1,4,7,8,9,10]
    arr2 = [2,3,6]
    print(merge_sorted(arr1,arr2))