# Find the repeating and missing numbers
# Problem Statement: You are given a read-only array of N integers with values also in the range [1, N] both inclusive.
#  Each integer appears exactly once except A which appears twice and B which is missing.
#  The task is to find the repeating and missing numbers A and B where A repeats twice and B is missing.

# method one :  using count sort : 

# method two :  using math
# we already know the sum of array = n*n-1/2
# sum of square = n*n+1*2n+1/6
#sum of array =sum(arr)
#sum of squares=sum(arr**2)


def find_missing(arr):
    n = len(arr)
    S = n*(n-1)//2
    P = n*(n+1)*(2*n+1)//6

    for i in range(len(arr)):
        S -= arr[i]
        P -= arr[i]*arr[i]

    missing_number = (S+P//S)//2

    repeating_number = missing_number-S 

    return [missing_number,repeating_number]

if __name__ == "__main__":
    a = [1,2,3,3,5]
    print(find_missing(a))