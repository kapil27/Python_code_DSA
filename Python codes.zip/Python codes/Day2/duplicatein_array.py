# Find the duplicate in an array of N+1 integers
# Problem Statement: Given an array of N + 1 size, 
# where each element is between 1 and N. Assuming there is only one duplicate number,
#  your task is to find the duplicate number.

# naive :  using sorting

# better :  using hash map

# using linkedlist pointers theory using slow and fast pointers
# The slow pointer moves by one step and the fast pointer moves by 2 steps and 
# there exists a cycle so the first collision is bound to happen.

def find(arr):
    slow = arr[0]
    fast = arr[0]
    flag = True
    while(slow!=fast or flag):
        flag = False
        slow = arr[slow]
        fast = arr[arr[fast]]
    # print(fast)
    # print(slow)
    fast = arr[0]
    while(slow!=fast):
        slow = arr[slow]
        fast = arr[fast]
    return slow

if __name__ == "__main__":
    a = [5,4,4,3,2,1]
    print(find(a))
