def l(n):
    prev2 = 0
    prev = 1
    cur = 0
    for i in range(2,n+1):
       cur = prev + prev2
       prev2 = prev
       prev = cur
    return cur
print(l(5))



def m(n):
    dp=[0]*(n+1)
    dp[0] = 0
    dp[1] = 1
    for i in range(2,n+1):
        dp[i] = dp[i-1]+dp[i-2]
    return dp
    
p = int(input())
print(m(p))

# def g(n):
#     if n<=0:
#         return False
#     if n==1:
#         return 1
#     if n==2:
#         return 1
#     return g(n-1)+g(n-2)

# p = int(input())
# for i in range(1,p+1):
#     print(g(i), " " )

# def f(n,dp):
#     if n<=0:
#         return "number should be greater than 0"
#     if n==1:
#         return 1
#     if n==2:
#         return 1
#     if n not in dp: 
#         dp[n] = f(n-1,dp)+f(n-2,dp)
#     return dp[n]

# n = int(input())
# dp = [-1]*(n+1)
# print(f(5,dp))
