# Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.

# You may assume that each input would have exactly one solution, and you may not use the same element twice.

# You can return the answer in any order.

def two_sum(nums,target):
    d={}
    for i,num in enumerate(nums):
        if target-num in d:
            return d[target-num], i
        d[num]=i

if __name__ == "__main__":
    nums = [1,2,3,4,5]
    target = 7
    print(two_sum(nums,target))