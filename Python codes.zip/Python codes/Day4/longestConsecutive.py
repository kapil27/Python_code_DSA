# Longest Consecutive Sequence in an Array
# Problem Statement: You are given an array of ‘N’ integers. You need to find the length of the longest sequence which contains the consecutive elements.

def longest(nums):
    nums = set(nums)
    best = 0
    for x in nums:
        if x - 1 not in nums:
            y = x + 1
            while y in nums:
                y += 1
            best = max(best, y - x)
    return best

if __name__ == "__main__":
    arr = [2,3,4,5,6,7,100,200]
    print(longest(arr))
