def majorityElement(nums):
        count = 0
        cur_element = 0
        for i in range(len(nums)):
            if count==0:
                cur_element = nums[i]
            if nums[i] == cur_element:
                count+=1
            else:
                count-=1
        return cur_element

if __name__ == "__main__":
    a = [1,1,1,1,4,5]
    print(majorityElement(a))