# Problem Statement: Given a double x and integer n, calculate x raised to power n. Basically Implement pow(x, n).

# Input: x = 2.00000, n = 10

# Output: 1024.00000

# Explanation: You need to calculate 2.00000 raised to 10 which gives ans 1024.00000

# just run a loop with printting x*x 

# for logn

def print_pow(x,power):
    ans = 1.0
    nn = power
    if nn<0:
        nn = -1*nn
    while(nn>0):
        if nn%2==1:
            ans = ans*x
            nn = nn-1
        else:
            x = x*x
            nn = nn/2
    if power<0:
        ans = 1.0/ans
    return ans

if __name__ == "__main__":
    x = 3.1
    power = 5
    print(print_pow(x,power))