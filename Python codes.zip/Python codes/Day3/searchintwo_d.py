def searchMatrix(matrix,target):
        low = 0
        high = len(matrix)*len(matrix[0])-1
        
        while(low<=high):
            middle = (low+high)//2
            if matrix[middle//len(matrix[0])][middle%len(matrix[0])] == target:
                return True
            if matrix[middle//len(matrix[0])][middle%len(matrix[0])]<target:
                low=middle+1
            else:
                high=middle-1
        # print(1)
        return False

if __name__ == "__main__":
    p = [[1,2,3,4,5],[7,8,9,10,11],[12,13,14,15,16]]
    print(searchMatrix(p,99))