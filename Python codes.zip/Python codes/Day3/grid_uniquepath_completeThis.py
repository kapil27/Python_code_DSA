# Grid Unique Paths | Count paths from left-top to the right bottom of a matrix
# Problem Statement: Given a matrix m X n, count paths from left-top to the right bottom of a matrix 
# with the constraintsthat from each cell you can either only move to the rightward direction
#  or the downward direction. 

#  Input Format: m = 2, n= 2
# Output: 2

# def uniquePaths(self, m: int, n: int) -> int:
#         return self.count_path(0,0,m,n)
    
#     def count_path(self,i,j,m,n):
#         if(i==(n-1) and j==(m-1)):
#             return 1
#         if(i>=n or j>=m):
#             return 0
#         else:
#             return self.count_path(i+1,j,m,n) + self.count_path(i,j+1,m,n)

#  above problem soln is exponential time complexity and exponential space complexity

# let's try dynamic approach

def count_path(i,j,n,m,arr):
    if i ==n-1 and j==m-1:
        return 1
    if i>=n or j>=m:
        return 0
    if (arr[i][j]!=-1):
        return arr[i][j]
    else:
        arr[i][j] = count_path(i+1,j,n,m,arr)+count_path(i,j+1,n,m,arr)
        # return arr[i][j] = count_path(i+1,j,n,m,arr)+count_path(i,j+1,n,m,arr)
    return 
    
def unique_path(m,n):
    arr = [[-1 for i in range(m+1)] for j in range(n+1)]
    num = count_path(0,0,m,n,arr)
    if m==1 and n==1:
        return num
    return arr[0][0]

def main():
    print(unique_path(3,7))
main()